// 数竞高频知识点原理讲解数据
// 每条是一个"为什么/怎么用"的拆解，公式用 LaTeX（不带 $），交给 MathRenderer 渲染

export interface ExplainerStep {
  title: string;
  body: string;
  formula?: string;
}

export interface ExplainerTopic {
  id: string;
  title: string;
  tag: string;
  essence: string;
  whenToUse: string[];
  steps: ExplainerStep[];
  example: {
    problem: string;
    walkthrough: string[];
    result: string;
  };
}

export const EXPLAINER_TOPICS: ExplainerTopic[] = [
  {
    id: 'rolle',
    title: '罗尔定理：构造辅助函数',
    tag: '中值定理',
    essence:
      '要证"存在一点使某个等式成立"，把等式移项成"某函数的导数=0"，再验证这个函数在区间两端值相等，罗尔定理自动给出答案。',
    whenToUse: [
      '结论里出现"存在 ξ ∈ (a,b)"',
      '函数在 [a,b] 连续、(a,b) 可导',
      '要证的式子含 f 与 f′ 的混合等式',
    ],
    steps: [
      {
        title: '移项归零',
        body: '把要证的等式右边全部移到左边，让右边 = 0。',
      },
      {
        title: '认出 F(x)',
        body: '把 ξ 换成 x，把左边认成某个 F(x) 的导数 F′(x)。常见导数形式：',
        formula: "(e^{x}f(x))'=e^{x}(f+f')\\quad(f(x)g(x))'=f'g+fg'\\quad(f(x)-ax-b)'=f'-a",
      },
      {
        title: '验两端',
        body: '验证 F(a)=F(b)。若不等，重新猜 F；若相等，进入下一步。',
      },
      {
        title: '套定理回代',
        body: '由罗尔定理，存在 ξ 使 F′(ξ)=0，回代即得要证的等式。',
      },
    ],
    example: {
      problem:
        'f 在 [0,1] 连续、(0,1) 可导，f(0)=0，f(1)=1，证存在 ξ 使 f′(ξ)=2ξ。',
      walkthrough: [
        '移项：f′(ξ)−2ξ=0。',
        '认出 F(x)=f(x)−x²，其导数 F′(x)=f′(x)−2x。',
        '验两端：F(0)=0−0=0，F(1)=1−1=0，相等。',
        '罗尔：存在 ξ 使 F′(ξ)=0，即 f′(ξ)=2ξ。',
      ],
      result: 'f′(ξ)=2ξ',
    },
  },
  {
    id: 'squeeze',
    title: '夹逼定理：怎么"夹"',
    tag: '极限',
    essence:
      '找两个上下界 g、h，让 g≤f≤h，且 g 和 h 的极限相等，那么 f 被"挤"到同一个极限。',
    whenToUse: [
      'n 项和/积的极限，每项有波动',
      '含 sin、cos 等有界振荡量',
      '直接算太繁，但能放缩到好算的形式',
    ],
    steps: [
      {
        title: '找振荡量的界',
        body: '先把有界函数夹住，例如 sin、cos 的范围是 [-1,1]。',
        formula: '-1\\le\\sin x\\le 1',
      },
      {
        title: '全式放缩',
        body: '不等式三边同时乘/加同号量，保持不等号方向，得到 g(n)≤aₙ≤h(n)。',
      },
      {
        title: '算两端极限',
        body: '分别求 lim g(n) 与 lim h(n)。',
      },
      {
        title: '等号成立',
        body: '若两端极限相同 L，则 lim aₙ=L。',
        formula: 'g(n)\\le a_n\\le h(n),\\ \\lim g=\\lim h=L\\ \\Rightarrow\\ \\lim a_n=L',
      },
    ],
    example: {
      problem: '求 lim_{n→∞} (sin n)/n。',
      walkthrough: [
        '由 −1≤sin n≤1，三边除以 n>0。',
        '得 −1/n ≤ (sin n)/n ≤ 1/n。',
        '两端极限：lim(−1/n)=0，lim(1/n)=0。',
        '夹逼：中间项极限也是 0。',
      ],
      result: '\\displaystyle\\lim_{n\\to\\infty}\\frac{\\sin n}{n}=0',
    },
  },
  {
    id: 'lhopital',
    title: '洛必达：什么时候才能用',
    tag: '极限',
    essence:
      '只有 0/0 或 ∞/∞ 型，且求导后极限存在（或为 ∞）时，才能上下分别求导再取极限。乱用必错。',
    whenToUse: [
      '代入后是 0/0 或 ∞/∞',
      '求导后式子更简单',
      '导函数之比极限存在',
    ],
    steps: [
      {
        title: '先定型',
        body: '代入 x→a，确认是 0/0 或 ∞/∞，不是这个型不能用。',
      },
      {
        title: '再验可导',
        body: '分母在邻域内不为 0，且分子分母都可导。',
      },
      {
        title: '分别求导',
        body: '分子、分母各自求导，不是对整个分式求导。',
        formula: '\\lim\\frac{f(x)}{g(x)}=\\lim\\frac{f\'(x)}{g\'(x)}',
      },
      {
        title: '可重复用',
        body: '若求导后仍是未定式，且条件满足，可再次洛必达。',
      },
    ],
    example: {
      problem: '求 lim_{x→0} (sin x)/x。',
      walkthrough: [
        '代入 x=0：0/0，是未定式。',
        '分子求导 cos x，分母求导 1。',
        '得 lim cos x / 1 = cos 0 = 1。',
      ],
      result: '\\displaystyle\\lim_{x\\to 0}\\frac{\\sin x}{x}=1',
    },
  },
  {
    id: 'taylor',
    title: '泰勒展开：阶数怎么选',
    tag: '级数',
    essence:
      '展到"抵消后余项刚好比需要的高阶"为止——多一项浪费，少一项消不掉。',
    whenToUse: [
      '求极限中含多个小量相加',
      '要判断无穷小的阶',
      '洛必达用不动的式子',
    ],
    steps: [
      {
        title: '标出每部分最低次',
        body: '看展开后各项 x 的幂次，找出最低那几项。',
        formula: '\\sin x=x-\\frac{x^3}{6}+o(x^3)',
      },
      {
        title: '抵消预测',
        body: '若两项最低次相同会相消，就多展一阶，直到出现不抵消的项。',
      },
      {
        title: '写皮亚诺余项',
        body: '末尾写 o(x^n)，表示高阶小量。',
      },
      {
        title: '代入求极限',
        body: '只保留最低非零次，比值即得极限。',
      },
    ],
    example: {
      problem: '求 lim_{x→0} (sin x − x)/x³。',
      walkthrough: [
        'sin x = x − x³/6 + o(x³)。',
        '分子 sin x − x = −x³/6 + o(x³)。',
        '除以 x³：−1/6 + o(1)。',
      ],
      result: '\\displaystyle\\lim_{x\\to 0}\\frac{\\sin x-x}{x^3}=-\\frac{1}{6}',
    },
  },
];
