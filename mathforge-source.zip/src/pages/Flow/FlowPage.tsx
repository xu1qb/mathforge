import { useState } from 'react';
import { ArrowLeft, Play, CheckCircle2, XCircle, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

interface FlowNode {
  id: string;
  title: string;
  desc: string;
  tag?: string;
  kind: 'start' | 'decision' | 'process' | 'end' | 'warn';
}

const NODES: FlowNode[] = [
  { id: 'start', title: '拿到极限题', desc: 'lim_{x→a} f(x)', kind: 'start' },
  { id: 'decide', title: '代入定型', desc: '直接代入看是哪型：0/0？∞/∞？还是有界振荡？', kind: 'decision', tag: '关键一步' },
  { id: 'lhopital', title: '0/0 或 ∞/∞', desc: '洛必达：分子分母分别求导，直到出定值', kind: 'process' },
  { id: 'taylor', title: '含多个小量相加', desc: '泰勒展开到不抵消的那一项，写皮亚诺余项', kind: 'process' },
  { id: 'squeeze', title: '有界振荡量', desc: '夹逼：放缩到上下界极限相等', kind: 'process' },
  { id: 'check', title: '条件不满足？', desc: '洛必达要求导后极限存在；泰勒要数对阶数', kind: 'warn' },
  { id: 'answer', title: '得到极限值', desc: '回代检查端点、阶数、符号', kind: 'end' },
];

const KIND_STYLE: Record<FlowNode['kind'], string> = {
  start: 'border-primary bg-primary/10',
  decision: 'border-amber-500/60 bg-amber-500/10',
  process: 'border-border bg-card',
  warn: 'border-red-500/60 bg-red-500/10',
  end: 'border-emerald-500/60 bg-emerald-500/10',
};

export default function FlowPage() {
  const navigate = useNavigate();
  const [openWarn, setOpenWarn] = useState(false);

  return (
    <div className="mx-auto w-full max-w-3xl px-4 py-6">
      <div className="mb-5 flex items-center gap-3">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground"
        >
          <ArrowLeft className="h-4 w-4" /> 返回
        </button>
        <h1 className="text-xl font-semibold">解题流程图</h1>
        <Badge variant="secondary">极限题怎么想</Badge>
      </div>

      <div className="flex flex-col items-center">
        {NODES.map((n, i) => (
          <div key={n.id} className="flex w-full flex-col items-center">
            <Card className={cn('w-full max-w-md border-2', KIND_STYLE[n.kind])}>
              <CardContent className="p-4">
                <div className="flex items-start gap-3">
                  <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">
                    {i + 1}
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">{n.title}</span>
                      {n.tag && (
                        <Badge variant="outline" className="text-xs">{n.tag}</Badge>
                      )}
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground">{n.desc}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* 节点间连线 */}
            {i < NODES.length - 1 && (
              <div className="my-1 flex flex-col items-center">
                <div className="h-5 w-px bg-border" />
                <ArrowRight className="h-4 w-4 rotate-90 text-muted-foreground" />
              </div>
            )}
          </div>
        ))}

        {/* 分支提示 */}
        <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
          <XCircle className="h-3.5 w-3.5 text-red-500" />
          条件不满足就退回上一步换方法
          <ArrowRight className="h-3.5 w-3.5" />
          <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
          满足就往下走
        </div>
      </div>
    </div>
  );
}
